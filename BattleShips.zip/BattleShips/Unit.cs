﻿namespace BattleShips
{
    class Unit
    {
        #region Fields
        #endregion

        #region Properties
        #endregion

        #region Constructor
        public Unit()
        {

        }
        #endregion

        #region Methods
        #endregion
    }
}
