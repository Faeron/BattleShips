﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BattleShips
{
    class FileManager
    {
        #region fields
        #endregion

        #region properties
        #endregion

        #region constructor
        #endregion
        
        #region methods
        #endregion
    }
}
