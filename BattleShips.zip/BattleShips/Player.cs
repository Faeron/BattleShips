﻿namespace BattleShips
{
    class Player
    {
        #region Fields
        #endregion

        #region Properties
        #endregion

        #region Constructor
        public Player()
        {

        }
        #endregion

        #region Methods
        #endregion
    }
}
